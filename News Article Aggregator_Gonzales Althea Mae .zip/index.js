var http = require('http');
var server = http.createServer( (request, response) => {
  response.end('Versions: ' + JSON.stringify(process.versions));
});
server.listen(3000, () => {
  console.log(`Server running at http://localhost:3000/`);
});

const express = require("express");
const bodyParser = require("body-parser");
const {
  loadArticles,
  saveArticles,
  calculateTotalViews,
  filterByCategory,
  findMostViewed,
  groupByAuthor,
  fetchNewArticles
} = require("./utils");

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

// GET all articles
app.get("/articles", (req, res) => {
  res.json(loadArticles());
});

// POST add new article
app.post("/articles", (req, res) => {
  const articles = loadArticles();
  articles.push(req.body);
  saveArticles(articles);
  res.json({ message: "Article added", article: req.body });
});

// DELETE article by title
app.delete("/articles/:title", (req, res) => {
  let articles = loadArticles();
  const before = articles.length;
  articles = articles.filter(a => a.title !== req.params.title);
  saveArticles(articles);
  res.json({ message: "Article deleted", deleted: before - articles.length });
});

// GET total views
app.get("/totalViews", (req, res) => {
  res.json({ totalViews: calculateTotalViews(loadArticles()) });
});

// GET filter by category
app.get("/filter/:category", (req, res) => {
  res.json(filterByCategory(loadArticles(), req.params.category));
});

